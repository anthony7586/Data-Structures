
#include<string>
// constructor
BookBot::BookBot(int seed)
  {
  srand(seed);
  }


vector<string> BookBot :: getValues(const string & key)
{
  return markov_chain[key];
}

//is end puntuation def
bool BookBot:: isEndPunctution(char character)
{
      if (character == '.' || character == '!' || character == '?' ) return true;
      else return false;
}

//readin function
void BookBot:: readIn(const string & filename)
{
ifstream myfile(filename);
string read;
string letter;
string lastLetter = "^";

      while(getline(myfile, read))
      {
        stringstream linestream(read);
            while(getline(linestream, letter, ' ' ))
            {
              sanatize(letter);

              int i = letter.size() - 1;

                    while(isEndPunctution(letter[i]))
                    {
                      i--;
                    }
                    int letterChoice = letter.size() - 1;

            if(i != letter.size() - 1)
            {
                if((letter[letterChoice]) == '!')
                {
                  letter.pop_back();

                  markov_chain[lastLetter].push_back(letter);
                  markov_chain[letter].push_back("!");
                  markov_chain["!"].push_back("$");
                }
                else if (letter[letterChoice] == '.')
                {
                  letter.pop_back();

                  markov_chain[lastLetter].push_back(letter);
                  markov_chain[letter].push_back(".");
                  markov_chain["."].push_back("$")
                }
                else if (letter[letterChoice] == '?')
                {
                  letter.pop_back();

                  markov_chain[lastLetter].push_back(letter);
                  markov_chain[letter].push_back("?");
                  markov_chain["?"].push_back("$")
                }
                lastLetter = "^";
            }//end ifstatements
          }//end of first while
        }//end of other while
        myfile.close();
      }//end of function read in

string BookBot:: generateSentence()
{
markov_chain[key];
  int itemOne;
  int itemTwo;
  string line;
  string p = ".";
  string q = "?";
  string key = "^";
  string moneySign = "$";
  string ex = "!";

itemOne = rand()%(getValues(key).size());
key = getvalues(key)[itemTwo];
line += key;

while (key != moneySign)
{
  itemTwo = rand() % (getValues(key).size());
  key = getValues(key)[itemTwo]

  if(key != moneySign)
  {
      if (key == p)
      {
        line += key;
      }
     if(key == q)
      {
        line += key;
      }
      if(key == ex)
      {
        line += key;
      }
      else
      {
        line += ' ' + key;
      }
  }
}

return line;


}//end of generateSentence
