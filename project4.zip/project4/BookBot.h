#include <fstream>
#include <vector>
#include <string>
#include <map>
#include<sstream>
#include <iostream>

#include "sanitize.h"
using namespace std;


class BookBot {
private:
    map< string, vector<string>> markov_chain;

public:
    BookBot(const unsigned int seed);//constructor done

    void readIn(const std::string & filename);
    bool isEndPunctuation(const char character);
    vector<string> getValues(const string & key);
    string generateSentence();
};




// constructor
BookBot::BookBot(const unsigned int seed)
  {
  srand(seed);
  }


vector<string> BookBot :: getValues(const string & key)
{
  return markov_chain[key];
}

//is end puntuation def
bool BookBot:: isEndPunctuation(char character)
{
      if (character == '.' || character == '!' || character == '?' ) return true;
      else return false;
}

//readin function
void BookBot:: readIn(const string & filename)
{
ifstream myfile(filename);
string read;
string letter;
string lastLetter = "^";

      while(getline(myfile, read))
      {
        stringstream linestream(read);
            while(getline(linestream, letter, ' ' ))
            {
              sanitize(letter);

              int i = letter.size() - 1;

                    while(isEndPunctuation(letter[i]))
                    {
                      i--;
                    }
                    int letterChoice = letter.size() - 1;

            if(i != letter.size() - 1)
            {
                if((letter[letterChoice]) == '!')
                {
                  letter.pop_back();

                  markov_chain[lastLetter].push_back(letter);
                  markov_chain[letter].push_back("!");
                  markov_chain["!"].push_back("$");
                }
                else if (letter[letterChoice] == '.')
                {
                  letter.pop_back();

                  markov_chain[lastLetter].push_back(letter);
                  markov_chain[letter].push_back(".");
                  markov_chain["."].push_back("$");
                }
                else if (letter[letterChoice] == '?')
                {
                  letter.pop_back();

                  markov_chain[lastLetter].push_back(letter);
                  markov_chain[letter].push_back("?");
                  markov_chain["?"].push_back("$");
                }
                lastLetter = "^";
            }//end ifstatements
          }//end of first while
        }//end of other while
        myfile.close();
      }//end of function read in

string BookBot:: generateSentence()
{

  int itemOne;
  int itemTwo;
  string line;
  string p = ".";
  string q = "?";
  string key = "^";
  string moneySign = "$";
  string ex = "!";
  markov_chain[key];

itemOne = rand()%(getValues(key).size());
key = getValues(key)[itemTwo];
line += key;

while (key != moneySign)
{
  itemTwo = rand() % (getValues(key).size());
  key = getValues(key)[itemTwo];

  if(key != moneySign)
  {
      if (key == p)
      {
        line += key;
      }
     if(key == q)
      {
        line += key;
      }
      if(key == ex)
      {
        line += key;
      }
      else
      {
        line += ' ' + key;
      }
  }
}

return line;


}//end of generateSentence
