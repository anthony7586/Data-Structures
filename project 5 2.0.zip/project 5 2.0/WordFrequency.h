#pragma once
#include <string>
#include<sstream>
#include <unordered_map>
#include "sanitize.h"
#include<fstream>

using namespace std;

class WordFrequency {
private:
	string filename;

public:
    WordFrequency(); // default constructor.didnt need to do.
	void insertLine(string& line); 
    void readIn(const string & filename); // add words from file to hash table.
        size_t numberOfWords(); // return the number of unique words.done
    size_t wordCount(const string & word); // return the number of occurrences of the given word.
    string mostFrequentWord(); // return the most frequent word.
    size_t maxBucketSize(); // return the size of the largest bucket in the hash table.
    bool isEndPunctution(char character);
};

unordered_map<string, int> mymap;//this is the map

WordFrequency:: WordFrequency(){}//constructor


// *****************************************************************************
//                             start of defenitions
// *****************************************************************************


//borrowed from project 4
bool WordFrequency:: isEndPunctution(char character)
{  if (character == '.' || character == '!' || character == '?' ) return true;
      else return false;}




//this is used within the readin function to insert a word into the map
void WordFrequency :: insertLine(string & line){
       istringstream ss(line);
        string word = "";
        while (!ss.eof()){//will continue until the end of file 
        ss >> word;
        sanitize(word);//sanatizes, then inserts 
            if (word != "")
                if (!isEndPunctution(word[word.size()-1])){
                  mymap[word]++;//inserts 
                }
                else{
                  mymap[word.substr(0,word.size()-1)]++;
                }}}






void WordFrequency :: readIn(const string & filename)//reads through the book/file inserting as it reads 
{
	name = filename;
ifstream file(filename);
  if(file.is_open()){
    while(!file.eof()){
              string line;
			  getline(file, line);
              if(line != ""){
                  insertLine(line);
                }
	}
  }file.close(); }





// return the number of unique words.
size_t WordFrequency :: numberOfWords(){return mymap.size();}




 // return the number of occurrences of the given word.
size_t WordFrequency :: wordCount(const string & word)
{return mymap[word];}





 //return the most frequent word.
string WordFrequency :: mostFrequentWord(){
  pair<string,size_t> mfrequent = pair<string,size_t>("",0);
    for(pair<string,size_t> word : mymap){
        if (word.second > mfrequent.second){
          mfrequent = word;
        }
    }return mfrequent.first;
}



//return the size of the largest bucket in the hash table
size_t WordFrequency :: maxBucketSize(){
  const size_t count(mymap.bucket_count());
  size_t largest = 0;

      for (size_t i= 0, curr_size; i< count; i++)
      {
          curr_size = mymap.bucket_size(i);
          if(curr_size > largest)
          {
            largest = curr_size;
          } }return largest;}
