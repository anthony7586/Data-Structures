#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <iterator>     // std::next, std::prev
#include<list>
using namespace std;//so that no std will have to repetitivley be written
using std::string;

// list<string> web_pages;
// string url;
// size_t filesize;
// string fileName;



class BrowserHistory {
public:
    BrowserHistory();

    void visitSite(string url, size_t filesize);
    void backButton();
    void forwardButton();

    void readFile(string fileName);

    string currentUrl();
    size_t currentPageSize();
    size_t getHistoryLength();

private:
    struct hItem{
      size_t filesize;
      string url;

      hItem();
      hItem(string url, size_t filesize);
    };


list<hItem> history;
list<hItem>:: iterator current;
};
/********************* defenitions for the struct functions below**************/
    BrowserHistory :: hItem :: hItem(){
                                      url = " ";
                                      filesize = 0;
                                      }
    BrowserHistory :: hItem :: hItem(string url, size_t filesize){
                                      this->url = url;
                                      this->filesize = filesize;
                                      }


//******************** the start of defenitions for the functions************//

//constructor
BrowserHistory ::BrowserHistory(){
  current = history.begin();  //makes the pointer point to the first item in the list
} //end of Constructor


 void BrowserHistory :: visitSite(string url, size_t filesize){
   if (!history.empty())
        while(current != prev(history.end()))
              history.pop_back();
        hItem temp_item(url,filesize);
        history.push_back(temp_item);
        current = prev(history.end());

 }


void BrowserHistory:: backButton(){
      if ( !history.empty() && current != history.begin() )
      {
        current--;
      }


}//end of back button
void BrowserHistory :: forwardButton(){
    if (!history.empty() && current != prev(history.end()))
    {
      current++;
    }
}//end of foward buttion

void BrowserHistory ::readFile(string fileName){
  ifstream myfile ("fileName");//using the file guven by user.
  if (myfile.is_open())
  {

      for (string command; !myfile.eof(); cin>> command)
      {
        if (command == "visit")
        {
          string url;
          size_t filesize;
          getline(myfile, url,' ');
          myfile.ignore();
          myfile >> filesize;
          visitSite(url, filesize);
        }
        else if (command == "back")
        {
          backButton();
        }
        else if(command == "foward")
        {
          forwardButton();
        }}
        myfile.close();
}}//end of if and end of read function

 string BrowserHistory :: currentUrl(){
   string nothing = " ";
      if (!history.empty())
      {
        return current->url;
      }return nothing;//end if the current url function
  }
 size_t BrowserHistory :: currentPageSize(){
    if (!history.empty())
    {
      return current->filesize;
    }return 0;//end of the page size function
 }
 size_t BrowserHistory :: getHistoryLength(){
   return history.size();
 }//end of the get length function
