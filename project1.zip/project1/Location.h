#include "PizzaZine.h"
#include<string>
using namespace std;

struct Location{

int priceRangeMax;
int priceRangeMin;
string name;
string address;
string city;
string province;
double latitude;
double longitude;
long postalCode;
};
