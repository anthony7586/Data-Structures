# Project 01 - PizzaZine
## CSUF CPSC 131, Fall 2019

Name and Email.

Group members:
- Anthony Ruiz anthony.ruiz@csu.fullerton.edu
